# Visuel Design Print — Angular 21 + Express

Site de prestation d'imprimerie grand format avec panneau d'administration.

## Stack technique

| Couche      | Technologie                                    |
|-------------|------------------------------------------------|
| Frontend    | Angular 21, Signals, Zoneless, Standalone      |
| Backend     | Node.js 20+, Express 5, JWT, Multer            |
| Base de données | JSON file (extensible vers MongoDB/PostgreSQL) |
| Styling     | SCSS, CSS Variables, Google Fonts              |

## Prérequis

- Node.js >= 20
- npm >= 10
- Angular CLI 21 : `npm install -g @angular/cli@21`

---

## Installation

### 1. Backend

```bash
cd backend
npm install
npm run dev        # Port 3000
```

**Variables d'environnement** (`backend/.env`) :
```env
PORT=3000
JWT_SECRET=vdp_super_secret_2025
JWT_EXPIRES_IN=7d
ADMIN_USER=admin
ADMIN_PASS=vdp2025
```

### 2. Frontend

```bash
cd frontend
npm install
ng serve           # Port 4200
```

---

## Structure du projet

```
visuel-design-print/
├── frontend/                         # Angular 21
│   └── src/app/
│       ├── core/
│       │   ├── models/               # Interfaces TypeScript
│       │   ├── services/             # EventsService, AuthService
│       │   └── guards/               # AuthGuard (signal-based)
│       ├── pages/
│       │   ├── home/                 # Page publique
│       │   │   └── sections/         # Hero, Services, About, etc.
│       │   ├── admin/                # Layout admin + routes enfants
│       │   │   ├── dashboard/
│       │   │   └── events-manager/
│       │   └── login/
│       └── shared/components/        # Navbar, Footer, Toast, Modal
└── backend/
    └── src/
        ├── routes/                   # auth.routes.js, events.routes.js
        ├── middleware/               # JWT middleware
        ├── data/db.json              # Persistance JSON
        └── server.js                 # Express entry point
```

## Identifiants admin (démo)

| Champ        | Valeur    |
|--------------|-----------|
| Utilisateur  | `admin`   |
| Mot de passe | `vdp2025` |

## API Endpoints

```
POST   /api/auth/login          — Connexion admin
GET    /api/events              — Liste des événements (public)
POST   /api/events              — Créer événement (auth)
PUT    /api/events/:id          — Modifier événement (auth)
DELETE /api/events/:id          — Supprimer événement (auth)
POST   /api/events/upload       — Upload image (auth)
```

## Commandes utiles

```bash
# Générer un nouveau composant Angular 21
ng g c pages/home/sections/portfolio --standalone

# Build production
cd frontend && ng build --configuration production

# Lancer les deux en parallèle (depuis la racine)
npm run dev
```
